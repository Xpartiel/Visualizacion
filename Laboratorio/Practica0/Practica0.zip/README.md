# Uriel Balderas Aguilar

## Juego del Ahorcado

### Compilacion
Para compilar el programa se recomienda ejecutar el comando...
make
mientras la terminal esta situada en la misma carpeta que este archivo.


### Ejecucion
Una vez compilado el programa, ejecutarlo ejecutando el siguiente comando:
./ahorcado